package com.retailedge.enums.customer;

public enum PurchaseType {
    NEW_PURCHASE,
    SERVICE,
    ACCESSORIES,
    OTHER
}
