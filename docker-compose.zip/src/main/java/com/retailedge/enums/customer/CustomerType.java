package com.retailedge.enums.customer;

public enum CustomerType {
    PURCHASE,
    SERVICE,
    OTHER
}
