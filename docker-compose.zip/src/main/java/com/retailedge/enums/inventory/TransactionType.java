package com.retailedge.enums.inventory;

public enum TransactionType {
        TRANSFER, RECEIVED
}