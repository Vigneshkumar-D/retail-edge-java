package com.retailedge.enums.ordertrack;

public enum OrderStatus {
    Ordered,
    Pending,
    Delivered,
    Canceled
}
