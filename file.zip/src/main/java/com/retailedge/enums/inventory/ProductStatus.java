package com.retailedge.enums.inventory;

public enum ProductStatus {
    IN_STOCK, OUT_OF_STOCK, TRANSFERED, RETURNED, SOLD
}
