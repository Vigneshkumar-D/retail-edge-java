package com.retailedge.enums.invoice;

public enum PaymentStatus {
    PENDING, COMPLETED, FAILED, REFUNDED
}