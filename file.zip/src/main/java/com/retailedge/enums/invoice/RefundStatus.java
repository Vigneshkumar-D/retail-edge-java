package com.retailedge.enums.invoice;

public enum RefundStatus {
    NOT_APPLICABLE, PENDING, COMPLETED
}