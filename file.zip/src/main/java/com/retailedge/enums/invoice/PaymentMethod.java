package com.retailedge.enums.invoice;

public enum PaymentMethod {
    CASH, CARD, UPI, FINANCE, CREDIT
}
